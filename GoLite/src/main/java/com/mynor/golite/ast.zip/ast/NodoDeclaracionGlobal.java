/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mynor.golite.ast;


/**
 *
 * @author mynordma
 */
public abstract class NodoDeclaracionGlobal extends NodoInstruccion {

    public NodoDeclaracionGlobal(int linea, int columna) {
        super(linea, columna);
    }
    
    
}
